#setwd("C:\\Users\\Public\\Coversheet_2_0\\Dir_Choose_Inter\\")

summary_name<- paste(smpl,tp,sep="_")
summary_name<- paste(dte,summary_name,sep="")
summary_name<- paste("Coversheet",summary_name,sep="_")
summary_name<- paste(summary_name,"docx",sep=".")

docpth <- paste(outside(),summary_name,sep="\\")

#write out the results
write.csv(res_check,file = paste(outside(),paste(smpl,"COVERSHEET_RESULTS.csv",sep="_"),sep="\\"))

####################################################################################################################################################

corrected<- read.csv("C:\\Users\\Public\\Coversheet_2_0\\Dir_Choose_Inter\\Panel_Corrects.csv",check.names=F,stringsAsFactors = F)

# change the naming
if(tp=="FP"){
  tp2<-"Final Product"
  okvx<- paste("Results are consistent with typical",tp2,sep=" ")
  okvx<- paste(okvx,"analysis",sep=" ")
}else{
  okvx<- paste("Results are consistent with typical",tp,sep=" ")
  okvx<- paste(okvx,"analysis",sep=" ")
}

## generic ok
ratio_v<-"CD4:CD8 ratio (historical control = 2) "


library(webshot)
library(officer)
library(magrittr)
library(flextable)
library(cowplot)
library(magick)
library(png)
library(grid)
library(flextable)
library(stringr)
library(dplyr)



crt_df <- function(df,pnl,conv=F){
  sub<- df[df$`Panel`==pnl,]
  sub2<-as.data.frame(sub$`RESULTS`)
  colnames(sub2)<-"RESULTS"
  if(conv==T){
    sub2<-as.data.frame(t(sub2))
    row.names(sub2)<-NULL
  }  
  # if(nrow(sub2) > 3 ){
  #    sub2<- sub2 %>%
  #      dplyr::mutate(a=str_extract(`RESULTS`,"^(.*)CAR\\+(.*)$"),
  #                    b=str_extract(`RESULTS`,"^(.*)CAR-(.*)$"),
  #                    grp=c(1,1,2,2) )%>%
  #      dplyr::select(-`RESULTS`)%>%
  #      dplyr::filter_all(any_vars(str_detect(.,pattern="<NA>",negate = T)))
  # vals2<-sub2[complete.cases(sub2$b),][2]
  # vals1<-sub2[complete.cases(sub2$a),][1]
  # sub2<-cbind(vals1,vals2)
  # }
  return(sub2)
}


crt_flx<- function(v){
  ft_merge <- flextable(v)
  ft_merge <- merge_h(x = ft_merge)
  ft_merge<-autofit(ft_merge)
  ft_merge<-delete_part(ft_merge,part="header")
  ft_merge<-border_remove(ft_merge)
  ft_merge <- autofit(ft_merge)
  ft_merge <- padding(ft_merge,padding.left =10,part="body")
  ft_merge <- padding(ft_merge,padding.bottom =.7,part="body")
  ft_merge <-align(ft_merge,align="left",part="body")
  ft_merge<-fontsize(ft_merge,size=10,part="body")
  ft_merge<-font(ft_merge,fontname = "arial")
  ft_merge<-height_all(ft_merge,height = 0)
  ft_merge<-width(ft_merge,width=0)
  ft_merge<-autofit(ft_merge,add_w=0)
  ft_merge<-autofit(ft_merge)
  return(ft_merge)
}

if(tp=="FP"){
  prec_car<-crt_df(cr_perc,"Isotype") #car percentage
}


### ratios
process_cdrat<- function(res){
  
  tce<-res %>%
    dplyr::filter(str_detect(`File Name`,"T cell subsets")) %>%
    dplyr::select(`Test`,`RESULTS`,`Panel`,`Population Name`,`Value`) %>%
    dplyr::mutate(cond = case_when(str_detect(.$`Test`,"FALSE") & length(unique(`Test`)) < 2 ~ okvx, # when test is false and there's only 1 unique value
                                   str_detect(.$`Test`,"TRUE") ~ "fail" )) 
  
  cdrat <- tce %>%
    dplyr:: filter(str_detect(`Population Name`,"ratio")) %>%
    dplyr::rowwise()%>%
    #dplyr::mutate(cr=str_extract(toString(`RESULTS`),pattern="(?=CAR+|-).*?(?=\\))")) %>%
    #dplyr::mutate(RESULTS=paste(as.character(`Value`),sep=str_extract(toString(`RESULTS`),pattern="(?=CAR+|-).*?(?=\\))")))
    dplyr::mutate(res=paste("[",paste(as.character(`Value`),str_extract(toString(`RESULTS`),pattern="(?=CAR+|-).*?(?=\\))"),sep=" ] ")))
  
  v<- as.data.frame(c(ratio_v,t(cdrat$res)))
  v<-as.data.frame(t(v))
  row.names(v)<-NULL
  
  v2<-tce %>%
    dplyr::filter(str_detect(`Population Name`,"ratio",negate=T))
  return(list(v,v2))
}

if(exists("res_check")){
  bad_ix <- row.names(res_check[res_check$Test=="TRUE",]) # where values failed threshold
  data_f <- res_check[,c("Population Name","Value","RESULTS")] # only bads
  data_fail <-subset(res_check,row.names(res_check)%in% bad_ix)
  data_fail2 <-merge(data_fail,corrected,all.x=T)
}
# count_vals<- function(df,xval){
#   ##count the values of Test based on Panel
#   require(dplyr)
#   dfx<- df %>% 
#     dplyr::filter(str_detect(`File Name`,xval)) %>%
#     dplyr::count(`Test`,`Panel`)
#   return(dfx)
# }

if( nrow(res_check[res_check$Panel=="Cell Subsets",]) > 0){
  
  cell_sub<-res_check %>%
    dplyr::filter(str_detect(`Panel`,"Cell Subsets")) %>%
    dplyr::select(`Test`,`RESULTS`,`Panel`,`Population Name`,`Value`) %>%
    dplyr::mutate(cond = case_when(str_detect(.$`Test`,"FALSE") & length(unique(`Test`)) < 2 ~ okvx,
                                   str_detect(.$`Test`,"TRUE") ~ gsub(pattern ="\\(of Live WBC single cells\\)","[",x =paste(`Population Name`,paste(`Value`,"]")))           
    )) 
  
  cell_sub_fail<- cell_sub %>%
    dplyr::filter(str_detect(.$`Test`,"TRUE"))%>%
    dplyr::mutate(cond= case_when(is.na(`cond`)!=T ~gsub(pattern="% % ","% ",x=paste(str_extract(toString(`RESULTS`),pattern="^[>|<]\\s\\d+%"),`cond`))))
  
  cell_sub<-cell_sub %>%
    dplyr::filter(str_detect(.$`cond`,'[:alnum:]')) %>%
    dplyr::filter(str_detect(.$`cond`,paste("[<|>]",okvx,sep="|")))
  

  cell_sub<-bind_rows(cell_sub,cell_sub_fail)
  
  bcellval<- res_check %>% 
    dplyr:: filter(str_detect(`Population Name`," B cells"))%>%
    dplyr:: mutate(cond = case_when(`Value`<  1 & tp == "FP" ~ "No Residual B Cells in Final Product",
                                    `Value` > 1 & tp == "FP" ~ paste(`Value`,"B Cells present in Final Product (>1 % Bcells)",sep=" "),
                                    `Value` < 1 & tp == "LKPK" ~ "< 1% Residual B cells in LKPK",
                                    `Value` > 1 & tp == "LKPK"~ paste(`Value`,"% B cells in LKPK",sep="")
                                    
    )) %>%
    select(`cond`)
  
}


if( nrow(res_check[res_check$Panel=="Cell Subsets",]) < 1 ){
  bcellval<-crt_flx(as.data.frame("Not Analyzed"))
}else{
    ## CELL SUBSETS
  bcell_raw<-as.data.frame(bcellval)
  #if(str_detect(bcell_raw$cond,"[:digit:]") & str_detect(bcell_raw$cond,"Residual",negate=T)==T){
  if(is.null(nrow(bcell_raw[str_detect(bcell_raw$cond,pattern = "[:digit:]"),]))){
    bcellval<-crt_flx(as.data.frame(bcell_raw$cond))
  }else{
    bcellval<-crt_flx(bcell_raw)
    bcellval<-color(bcellval,color="red",part="all")
  }
}

    
########################################################################### cell subsets
if( nrow(res_check[res_check$Panel=="Cell Subsets",]) > 0){
  if(nrow(subset(cell_sub,cell_sub$Test=="FALSE"))==5){
    cellsub_rep<-unlist(unique(cell_sub$cond))
    #cellsub_rep<-fpar(ftext(cellsub_rep),fp_p=fp_par(text.align = "left"))
    cellsub_rep<-crt_flx(as.data.frame(cellsub_rep))
    cellsub_rep<-autofit(cellsub_rep)
  
  }else{
    cellsub_rep<-subset(cell_sub,cell_sub$Test=="TRUE")
    cellsub_rep<-crt_flx(as.data.frame(cellsub_rep$cond))
    cellsub_rep<-color(cellsub_rep,color="red",part="all")
    cellsub_rep<-autofit(cellsub_rep)
  }
}

if( nrow(res_check[res_check$Panel=="Cell Subsets",]) < 1){
  cellsub_rep=crt_flx(as.data.frame("Not Analyzed"))
  }


############################################################################## Tcell subsets
if( nrow(res_check[res_check$Panel=="T cell subsets",]) < 1){
    cdrat<-crt_flx(as.data.frame("Not Analyzed"))
    tcellsubs<-crt_flx(as.data.frame(""))
}

if (nrow(res_check[res_check$Panel=="T cell subsets",]) > 0) {
    rs<- process_cdrat(res_check)
    #cdrat
    cdrat_raw<-as.data.frame(rs[1])
    if(tp=="LKPK"){
      cdrat_raw$V2 <- paste("=",gsub(pattern="CAR\\-",replacement="",x=cdrat_raw$V2))
    }
    cdrat_col<-as.numeric(ncol(cdrat_raw))
    cdrat<-crt_flx(cdrat_raw)
    cdrat<-color(cdrat,j=2:cdrat_col,color="blue") # ALWAYS
    cdrat<-autofit(cdrat,add_w = 0)
}

tcell_subsets_raw<- as.data.frame(rs[2])



if(tp=="FP"){
  tcel<-crt_df(tcell_subsets_raw,"T cell subsets")
  tcellsubs<-dplyr::bind_rows(prec_car,tcel) # add Car% if Final Product
  tcellsubs<-crt_flx(tcellsubs)
}
if(tp=="LKPK"){
  dftcellsub<-crt_df(tcell_subsets_raw,"T cell subsets")
  dftcellsub$RESULTS <- gsub(pattern="for CAR\\-",replacement="",x=dftcellsub$RESULTS)
  dftcellsub$RESULTS <- gsub(pattern="Tcyto",replacement="Cytotoxic cells",x=dftcellsub$RESULTS)
  dftcellsub$RESULTS <- gsub(pattern="Thelper",replacement="Helper cells",x=dftcellsub$RESULTS)
  tcellsubs<-crt_flx(dftcellsub)
}

#format
tcellsubs<-fontsize(tcellsubs,size=11,part="body")
tcellsubs<-autofit(tcellsubs)
tcellsubs<-height_all(tcellsubs,height = 0)




#reds<- fp_text(color = "red",font.size=11,bold=T)

# coalesce_by_column <- function(df) {
#   return(coalesce(df[1], df[2]))
# }
# coalesce_by_column <- function(df) {
#   return(dplyr::coalesce(!!! as.list(df)))
# }




#rgx1<-"^(.*)CAR\\+(.*)\\(E\\+EM\\).*(?=[<|>])"
#as.data.frame(do.call(rbind, strsplit(m, "Helper")))
#as.data.frame(str_match(m$RESULTS, "^(.*)CAR\\+(.*)$")[,-1])

#flx<-flextable(tcellsubs)
#flx<-merge_at(flx,i=3:4,j=2)

#flx<-merge_v(flx)
#flx<-autofit(flx)  
# flx<-delete_part(flx,part="header")
  # flx<-delete_part(flx,part="footer")
  # ft <- border_remove(x = flx)
  # myft <- autofit(ft)
  # myft <- padding(myft,padding=1,part="body")
  # myft <-align(myft,align="left",part="body")
  # myft<-fontsize(myft,size=11,part="body")
  # myft<-font(myft,fontname = "arial")
  # myft<-height_all(myft,height = 0)
  # return(myft)


################################################################################# Exhausted
## 
exh_raw<-crt_df(res_check,"Exhausted")


# if there are no rows with "Exhausted"
if(nrow(exh_raw)< 1){
  exhausted<-crt_flx(as.data.frame("Not Analyzed"))
}


# if there are rows greater than nothing in Exhausted
if(nrow(exh_raw)> 0){
  exh_raw<-merge(exh_raw,corrected,all.x=T) # add colnames via merge
  exh_raw<-exh_raw %>%
    dplyr::filter(str_detect(`final`,"<",negate=T)) # filter for lower than vals
  if(nrow(exh_raw)< 1){
    exhausted<-crt_flx(as.data.frame("T cells are not exhibiting signs of exhaustion"))
  }else{
  if(tp =="LKPK"){
    exh_raw$final <- gsub(pattern="for CAR\\-",replacement="",x=exh_raw$final)# don't say CAR neg when LKPK
  }
  exh_raw<-as.data.frame(exh_raw[,c("final")])
  colnames(exh_raw)<-"final"
  
  if(tp=="FP"){
    
    ##pd1
    pd1_df<-exh_raw %>%
      dplyr::filter(str_detect(`final`,pattern = "LAG|TIM|2B4",negate=T))
    colnames(pd1_df)<-"comb"
  ########################################## CAR POS
    # lag 3
    exh_raw_cpos_lg3<-exh_raw %>%
      dplyr::filter(str_detect(`final`,pattern = "CAR[+]"))%>% 
      dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                               str_extract(`final`,pattern = "LAG-3[+]")))%>%
      dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
      dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                    "CD279+/CD223+ (PD-1+/LAG-3+) expression on Cytotoxic & Helper T cells for CAR+",
                                                                                    sep=" "),`final`)) %>%
      dplyr::select(`comb`)
    
    ## tim3
    exh_raw_cpos_tim3<-exh_raw %>%
      dplyr::filter(str_detect(`final`,pattern = "CAR[+]"))%>% 
      dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                               str_extract(`final`,pattern = "TIM-3[+]")))%>%
      dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
      dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                    "CD279+/CD223+ (PD-1+/TIM-3+) expression on Cytotoxic & Helper T cells for CAR+",
                                                                                    sep=" "),`final`)) %>%
      dplyr::select(`comb`)
    
    # 2B4
    exh_raw_cpos_2b4<-exh_raw %>%
      dplyr::filter(str_detect(`final`,pattern = "CAR[+]"))%>% 
      dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                               str_extract(`final`,pattern = "2B4[+]")))%>%
      dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
      dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                    "CD279+/CD244+ (PD-1+/2B4+) expression on Cytotoxic & Helper T cells for CAR+",
                                                                                    sep=" "),`final`)) %>%
      dplyr::select(`comb`)
  # tot_lag_cpos<-as.numeric(nrow(exh_raw_cpos[str_detect(exh_raw_cpos$prim,"LAG"),]))
  # tot_tim_cpos<-as.numeric(nrow(exh_raw_cpos[str_detect(exh_raw_cpos$prim,"TIM"),]))
  
  ################################################# CAR NEG
  
  # LAG3  
  exh_raw_cneg_lg3<-exh_raw %>%
    dplyr::filter(str_detect(`final`,pattern = "CAR[-]"))%>% 
    dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                                          str_extract(`final`,pattern = "LAG-3[+]")))%>%
    dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
    dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                  "CD279+/CD223+ (PD-1+/LAG-3+) expression on Cytotoxic & Helper T cells for CAR-",
                                                                                  sep=" "),`final`)) %>%
    dplyr::select(`comb`)
  
  ## TIM 3
  exh_raw_cneg_tim3<-exh_raw %>%
    dplyr::filter(str_detect(`final`,pattern = "CAR[-]"))%>% 
    dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                             str_extract(`final`,pattern = "TIM-3[+]")))%>%
    dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
    dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                 "CD279+/CD223+ (PD-1+/TIM-3+) expression on Cytotoxic & Helper T cells for CAR-",
                                                                                 sep=" "),`final`)) %>%
    dplyr::select(`comb`)
  
  # 2B4
  exh_raw_cneg_2b4<-exh_raw %>%
    dplyr::filter(str_detect(`final`,pattern = "CAR[-]"))%>% 
    dplyr::mutate(prim=paste(str_extract(`final`,pattern=".*(?<=%)"),
                             str_extract(`final`,pattern = "2B4[+]")))%>%
    dplyr::filter(str_detect(`prim`,"NA",negate=T))%>%
    dplyr::mutate(comb=ifelse(length(`prim`)==2 & length(unique(`prim`))==1,paste(`prim`,
                                                                                  "CD279+/CD244+ (PD-1+/2B4+) expression on Cytotoxic & Helper T cells for CAR-",
                                                                                  sep=" "),`final`)) %>%
    dplyr::select(`comb`)
  
  
  
  
  #### combine
  exh_tgthr<-dplyr::bind_rows(exh_raw_cneg_lg3,exh_raw_cneg_tim3,exh_raw_cneg_2b4,
                              exh_raw_cpos_lg3,exh_raw_cpos_tim3,exh_raw_cpos_2b4)
  ## combine with PD1 
  exh_tgthr<-dplyr::bind_rows(exh_tgthr,pd1_df)
  
  colnames(exh_tgthr)<-"comb"
  exh_tgthr<-exh_tgthr[!duplicated(exh_tgthr$comb),]
  
  #df_exh<-as.data.frame(exh_raw_cneg_lg3[1],exh_raw_cneg_lg3[1])
  }
  }
}#else{
  #exhausted<-crt_flx(as.data.frame("T cells are not exhibiting signs of exhaustion"))
#}
if(!exists("exhausted")){
  if(tp=="LKPK"){
    exhausted<-crt_flx(exh_raw)
  }
}

if(exists("exh_tgthr")){
  exhausted<-crt_flx(as.data.frame(exh_tgthr))
}
               
                  
  #tot_lag_cneg<-as.numeric(nrow(exh_raw_cneg[str_detect(exh_raw_cneg$prim,"LAG"),]))
  #tot_tim_cneg<-as.numeric(nrow(exh_raw_cneg[str_detect(exh_raw_cneg$prim,"TIM"),]))
  
 
   

  #exhausted<-crt_flx(exh_raw)

  #exhausted<-color(exhausted,"red")
  



#exhausted<-crt_flx(as.data.frame(exh_raw))
if (nrow(res_check[res_check$Panel=="Senescence ",]) > 0 ){
  Senescence_raw<-crt_df(data_fail2,"Senescence ")
  Senescence_raw<-merge(Senescence_raw,corrected)
  if(tp =="LKPK"){
    Senescence_raw$final <- gsub(pattern="for CAR\\-",replacement="",x=Senescence_raw$final)
  }
  if(nrow(Senescence_raw)> 0){
    Senescence<-as.data.frame(Senescence_raw[,c("final")])
    Senescence<- crt_flx(Senescence)
    #Senescence<-color(Senescence,"red")
  }else{
    Senescence<-crt_flx(as.data.frame("T cells are not exhibiting signs of senescence"))
  }
}

if (nrow(res_check[res_check$Panel=="Senescence ",]) < 1 ){
  Senescence<-crt_flx(as.data.frame("Not Analyzed"))
}
#################################################################################   ACtivated Panel
###################################### not analyzed  Activated
if (nrow(res_check[res_check$Panel=="Activated-Treg",]) < 1 ){
  actx<-crt_flx(as.data.frame("Not Analyzed"))
  treg<- crt_flx(as.data.frame(" "))
  
}

if (nrow(res_check[res_check$Panel=="Activated-Treg",]) > 0 ){
  act_raw <-res_check[res_check$Panel=="Activated-Treg",]
  act_raw <- merge(act_raw,corrected)
  if(tp =="LKPK"){
    act_raw$final <- gsub(pattern="for CAR\\-",replacement="",x=act_raw$final)
  }
}
if(exists("act_raw")){
  if(nrow(act_raw[act_raw$Test=="TRUE",]) < 1){
    if(tp=="FP"){
      act_ok<-as.data.frame(okvx)
      colnames(act_ok)<-"final"
      #actx<-as.data.frame(act_raw$final)
      #actx<-dplyr::bind_rows(act_ok,actx)
      actx<-crt_flx(act_ok)
      treg<-crt_flx(as.data.frame(""))
    }
  }
if(nrow(act_raw[act_raw$Test=="TRUE",]) < 1){
  if(tp=="LKPK"){
    act_ok<-as.data.frame(okvx)
    colnames(act_ok)<-"final"
    tregval<- act_raw %>%
      dplyr::filter(str_detect(`RESULTS`,"%Tregs")) %>%
      dplyr::mutate(cond=gsub(pattern="% %",replacement="% ",x=paste('[',paste(`Value`," ] ",sep=""))))%>%
      dplyr::mutate(cond=gsub(pattern="% %",replacement="% ",x=paste(`final`,`cond`)))
    actx<- act_raw %>%
      dplyr::filter(str_detect(`RESULTS`,"%Tregs",negate=T))%>%
      dplyr::select(`final`)
    treg<- crt_flx(as.data.frame(tregval$cond))
    treg<-color(treg,color="red",part="all")
    actx<-crt_flx(actx)
  }

}
if(nrow(act_raw[act_raw$Test=="TRUE",]) > 1){
  act_ok<-as.data.frame(okvx)
  colnames(act_ok)<-"final"
  tregval<- act_raw %>%
    dplyr::filter(str_detect(`RESULTS`,"%Tregs")) %>%
    dplyr::mutate(cond=gsub(pattern="% %",replacement="% ",x=paste('[',paste(`Value`," ] ",sep=""))))%>%
    dplyr::mutate(cond=gsub(pattern="% %",replacement="% ",x=paste(`final`,`cond`)))
  actx<- act_raw %>%
    dplyr::filter(str_detect(`RESULTS`,"%Tregs",negate=T))%>%
    dplyr::select(`final`)
  treg<- crt_flx(as.data.frame(tregval$cond))
  treg<-color(treg,color="red",part="all")
  actx<-crt_flx(actx)
}
}else{
  actx<-crt_flx(as.data.frame(" "))
}

#     #actx<-as.data.frame(act_raw)
# if(nrow(act_raw[act_raw$Test=="TRUE",]) < 1)
#   if(tp=="LKPK"){
#       tregval<- act_raw %>%
#         dplyr::filter(str_detect(`RESULTS`,"%Tregs")) %>%
#         dplyr::mutate(cond= paste(`Value`,"% Tregs"))
#       actx<- act_raw %>%
#         dplyr::filter(str_detect(`RESULTS`,"%Tregs",negate=T))%>%
#         dplyr::select(`final`)
#       row.names(tregval)<-NULL
#       treg<- crt_flx(as.data.frame(tregval$cond))
#       treg<-color(treg,color="red",part="all")
#       actx<-crt_flx(actx)
#   }
#     if(tp=="FP"){
#       actx<-crt_flx(as.data.frame(act_raw))
#       treg<- crt_flx(as.data.frame(" "))
#   }
#   }
# }


# if(tp=="LKPK"){
#   tregval<- act_raw %>%
#     dplyr::filter(str_detect(`RESULTS`,"%Tregs")) %>%
#     dplyr::mutate(cond= paste(`Value`,"% Tregs")) 
#   actx<- act_raw %>%
#     dplyr::filter(str_detect(`RESULTS`,"%Tregs",negate=T))%>%
#     dplyr::select(`RESULTS`)
#   row.names(tregval)<-NULL
#   treg<- crt_flx(as.data.frame(tregval$cond))
#   treg<-color(treg,color="red",part="all")
#   actx<-crt_flx(actx)
# }else{
#   actx<-crt_flx(as.data.frame(act_raw))
#   treg<- crt_flx(as.data.frame(" "))
# }



###################################################################################################################################
# text paramaters
bold_face <- shortcuts$fp_bold(font.size=11)


par0 <- fpar(ftext("Post Analysis Notes:",prop=bold_face),fp_p = fp_par(text.align = "left",padding.bottom = 8))
par1 <- fpar(ftext(paste("Sample",smpl,sep=":   \t"),prop= bold_face),fp_p = fp_par(padding.bottom = 2))
par2 <- fpar(ftext(paste("Time Point",tp,sep=":   \t"),prop=bold_face),fp_p=fp_par(padding.bottom=2))
par3 <- fpar(ftext("Method:   \tCM64007A",prop=bold_face),fp_p = fp_par(padding.bottom=2))
par4 <- fpar(ftext(paste("Date Collected",cor,sep=":   \t"),prop=bold_face),fp_p = fp_par(padding.bottom=2))
par5 <- fpar(ftext(paste("Panels Collected: 1 -",pnls,sep=" "),prop=bold_face),fp_p=fp_par(padding.bottom=2))
par6 <- fpar(ftext(paste("Panels Analyzed: 1 -",pnls,sep=" "),prop=bold_face),fp_p = fp_par(padding.bottom=4))


## set up the Panels
cellp <- fpar(ftext("1. Cell Populations:",prop=bold_face),fp_p=fp_par(padding.bottom = 1,padding.top = 2))

tcel_sub <- fpar(ftext("2. T cell Subsets:",prop=bold_face),fp_p=fp_par(padding.top = 3,padding.bottom = 1.5))

Exh <- fpar(ftext("3. Exhausted (Checkpoint Inhibitors):",prop=bold_face),fp_p=fp_par(padding.top=3,padding.bottom=1.5))

Im <- fpar(ftext("4. Immunosenescence:",prop=bold_face),fp_p=fp_par(padding.top=3,padding.bottom=1.5))

Act <-fpar(ftext("5. Activation/Tregs:",prop=bold_face),fp_p=fp_par(padding.top=3,padding.bottom=1.5))

bc <- fpar(ftext("6. B cell Lineage:",prop=bold_face),fp_p=fp_par(padding.bottom=1.5))  

#name vales
nam_val <- fpar(ftext("Analyzed By:\t\t\t\t\t\t\tReviewed By:",prop=bold_face))

#prep doc
doc <- read_docx(path = "C:\\Users\\Public\\Coversheet_2_0\\Dir_Choose_Inter\\Doc1.docx")

## write out
doc <- doc %>%
  #body_add_par(" ") %>%
  #body_add_img(src="./clients-novartis.png",width=2.5,height=1.5,style="toc 1",pos="before")%>%
  #body_add_img(src="./clients-novartis_cropped.png",width=2.5,height=1,style="toc 1",pos="before")%>%
  body_add_img(src="C:\\Users\\Public\\Coversheet_2_0\\Dir_Choose_Inter\\clients-novartis.png",width=1.75,height=1,pos="on")%>%
  body_add_fpar(par1)%>%
  body_add_fpar(par2) %>%
  body_add_fpar(par3) %>%
  body_add_fpar(par4) %>%
  body_add_fpar(par5) %>%
  body_add_fpar(par6) %>%
  #body_add_par(" ") %>%
  body_add_fpar(par0) %>%
  #body_add_par(" ") %>%
  body_add_fpar(cellp)%>%
  body_add_flextable(cellsub_rep,align="left") %>%
  body_add_fpar(tcel_sub)%>%
  body_add_flextable(cdrat,align="left")%>%
  body_add_flextable(tcellsubs,align="left") %>%
  body_add_fpar(Exh)%>%
  body_add_flextable(exhausted,align = "left")%>%
  body_add_fpar(Im) %>%
  body_add_flextable(Senescence,align = "left")%>%
  body_add_fpar(Act)%>%
  body_add_flextable(actx,align= "left")%>%
  body_add_flextable(treg,align = "left")%>%
  body_add_par(" ")%>%
  body_add_fpar(bc)%>%
  #body_add_flextable(bcellval)%>%
  body_add_flextable(bcellval,align = "left")%>%
  body_add_par(" ")%>%
  body_add_fpar(nam_val)


print(doc, target = docpth)