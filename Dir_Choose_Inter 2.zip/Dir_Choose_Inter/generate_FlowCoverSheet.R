# @Author: Samson Jacob 15JUNE2020
# C:\Users\jacobsa6\R.exe

if(exists("test")){
  #get important vals
  tp<- as.character(unique(test$`Time Point`)) # timepoint
  smpl<-as.character(unique(test$`Experiment Id`)) # experiment ID
  smpl<-gsub(pattern = tp,replacement = "",smpl)
  pnls<-as.character(length(unique(test$Panel))) # panels analyzed
  dte <- format(as.Date(unique(test$Date)),'%d-%m-%Y') # date
  mon <- months.Date(as.Date(unique(test$Date)),abbreviate = T) # date
  cor<-gsub(pattern = "-\\d{2}-",paste(paste("-",mon,sep=""),"-",sep=""),x=dte)
}


#ignore warnings
options(warn=-1)
#load the pops
source("C:\\Users\\Public\\Coversheet_2_0\\Dir_Choose_Inter\\common_pops.R",local = T)

if (nrow(test[test$Panel=="T cell subsets",])>0) {
  # pre- process tcell subsets
  eff=analyze_tcellsub(test)

  # get the cd4:cd8 ratio (ALWAYS need)
  cdrat_test <- eff %>%
    dplyr:: filter(str_detect(`Population Name`,"ratio"))
  cdrat_test["Test"]<- TRUE
  cdrat_test["RESULTS"]<-gsub(")=","=",paste(cdrat_test$`Population Name`,cdrat_test$Value,sep=" ="))
  cdrat_test["RESULTS"]<-gsub("of","(historical control == 2",cdrat_test$RESULTS)
  cdrat_test["Threshold"]<-NA
  cdrat_test<-cdrat_test[,colx]
  
  # Panel 2 effective ratio
  Panel2 <-analyze_panel(eff,"T cell subsets",c(50,50,50,50),c("Sum_Effector of CAR- Tcyto","Sum_Effector of CAR- Thelper","Sum_Effector of CAR+ Tcyto","Sum_Effector of CAR+ Thelper"))
  Panel2_low <-analyze_panel(eff,"T cell subsets",c(50,50,50,50),c("Sum_Effector of CAR- Tcyto","Sum_Effector of CAR- Thelper","Sum_Effector of CAR+ Tcyto","Sum_Effector of CAR+ Thelper"),neg=T)
  Panel2<-dplyr::bind_rows(Panel2,Panel2_low)
  Panel2<-subset(Panel2,Panel2$Test==TRUE)
  panel2list<-str_extract(string=Panel2$RESULTS,pattern=".*(?<=%)")
  panel2list_cnt <- panel2list[str_detect(pattern="< 50%",string=as.character(panel2list))]
  panel2_carlist<-str_extract(string=Panel2$`Population Name`,pattern="CAR[+|-]")
  panel2_cellist<-str_extract(string=Panel2$`Population Name`,pattern="([T])\\w+")
  cpos_cnt<-length(panel2_carlist[grep(x=panel2_carlist,pattern = "CAR[+]")])
  cneg_cnt<-length(panel2_carlist[grep(x=panel2_carlist,pattern = "CAR[-]")])
  Panel2$RESULTS<-paste(paste(paste(panel2list,gsub(Panel2$RESULTS,"Sum_Effector of","terminal matured (E+EM) for"),sep=" "),panel2_carlist,sep=" " ),panel2_cellist,sep=" ")
}
#   if(panel2list_cnt > 0){
#     cpos_p2<-Panel2%>%
#       dplyr::filter(str_detect(`RESULTS`,"CAR[+]"))%>%
#       dplyr::mutate(RESULTS="<50% terminal matured (E+EM) for CAR+ in Tcyto & Thelper cell subset")
#     cneg_p2<-Panel2%>%
#       dplyr::filter(str_detect(`RESULTS`,"CAR[-]"))%>%
#       dplyr::mutate(RESULTS="<50% terminal matured (E+EM) for CAR- in Tcyto & Thelper cell subset")
#   }
#   if(cpos_cnt>0){
#     corrected_P2<-dplyr::bind_rows(cneg_p2,cpos_p2)
#     corrected_P2<-corrected_P2 %>%
#                 dplyr::distinct(`RESULTS`,.keep_all=T)
#   }
# }
# 
# if(exists("corrected_P2")){
#   Panel2<-corrected_P2
# }

### Add car percent from Isotypes
if(tp=="FP"){
  cr_perc<-test %>%
    dplyr::filter(`Population Name`=="% CAR+ (of T cells)", `Panel`=="Isotype")%>%
    dplyr::mutate(Test=TRUE)
    cr_perc["RESULTS"]=paste("%CAR +",cr_perc$Value,sep=" =")
    cr_perc["Threshold"]<-NA
    cr_perc<-cr_perc[,colx]
}



######################################################### SUMMED Populations
if (nrow(test[test$Panel=="Exhausted",]) >0) {
  # Panel 3 mutations
  Panel3 <- analyze_panel(test,"Exhausted",panel3_thresh,panel3_vals)
  
}


##############################################################################
if(nrow(test[test$Panel=="Cell Subsets",]) >0){
  #straightforward panels
  Panel1 <- analyze_panel(test,"Cell Subsets",panel1_thresh,panel1_vals)
  if(tp=="FP"){
    tcel_test <- analyze_panel(test,"Cell Subsets",c(95),c("% T cells  (of Live WBC single cells)"),neg=T)
  } 
}

if(nrow(test[test$Panel=="Senescence ",]) >0){
  Panel4 <- analyze_panel(test,"Senescence ",panel4_thresh,panel4_vals) 
  # ED panel is less than
  ed_test <- analyze_panel(test,"Senescence ",ed_thresh,ED_Panel,neg=T)
}

if (nrow(test[test$Panel=="Activated-Treg",]) > 0 ){
  # correct Activation panel by TimePoint
  if(tp=="LKPK"){
    act_test <- analyze_panel(test,"Activated-Treg",Activation_thresh,Activation_Panel)
  }else{
    act_test <- analyze_panel(test,"Activated-Treg",Activation_thresh,Activation_Panel,neg=T)
}
}



# if(tp=="LKPK"){
#   eff_memvalues<-eff_memvalues[str_detect(eff_memvalues,"CAR\\+",negate=T)]
#   eff_values<-eff_values[str_detect(eff_values,"CAR\\+",negate=T)]
# }


# eff_sumtest<-generate_effsums(test)

############################################################################## collect results
#found_pnls<-grep("Panel\\d",names(.GlobalEnv),value=TRUE) #panel1 panel3 panel4
#found_tst<-grep("_test",names(.GlobalEnv),value=TRUE)

#found_pnls<-grep("Panel\\d",names(parent.frame()),value=TRUE) #panel1 panel3 panel4
#found_tst<-grep("_test",names(parent.frame()),value=TRUE)



#found_pnls<-list(Panel1,Panel3,Panel4)

found_pnls<-list()

n<-0
if(exists("Panel1")){
   n<-n+1
   found_pnls[[n]]<-Panel1
}
if(exists("Panel2")){
  n<-n+1
  found_pnls[[n]]<-Panel2
}

if(exists("Panel3")){
  n<-n+1
  found_pnls[[n]]<-Panel3
}

if(exists("Panel4")){
  n<-n+1
  found_pnls[[n]]<-Panel4
 }




found_pnls<-lapply(found_pnls,
                   function(x){colnames(x)<-colx
                   return(x)})

#tst_fnd<-dplyr::bind_rows(found_pnls)

#################################################################################
#found_tst<-list(tcel_test,cdrat_test,ed_test,act_test)


found_tst<-list()

n<-0
if(exists("tcel_test")){
  n<-n+1
  found_tst[[n]]<-tcel_test
}


if(exists("cdrat_test")){
  n<-n+1
  found_tst[[n]]<-cdrat_test
}

if(exists("ed_test")){
  n<-n+1
  found_tst[[n]]<-ed_test
}

if(exists("act_test")){
  n<-n+1
  found_tst[[n]]<-act_test
}

found_tst<-lapply(found_tst,
                  function(x){colnames(x)<-colx 
                  return(x)})


#panels_found<-bind(found_pnls,found_tst)

#df_list <- list()

# standradize all of the extended population dataframes
# for(n in 1:length(panels_found)){
#   temp <- as.data.frame(mget(panels_found[n]))
#   colnames(temp)<-colx
#   df_list[[n]]<-temp
# }

res_check <- dplyr::bind_rows(found_pnls,found_tst)

## add car percentage
# if(exists("cr_perc")){
#   res_check<-dplyr::bind_rows(res_check,cr_perc)
# }

# Write outfile

# # correct cell subsets
 if(tp=="FP"){
   tcel <- analyze_panel(test,"Cell Subsets",c(95),c("% T cells  (of Live WBC single cells)"),neg=T)
   res_check <-dplyr::bind_rows(res_check,tcel)
 } 

if(tp=="LKPK"){
  res_check<- res_check %>%
    dplyr:: filter(str_detect(`Population Name`,"CAR\\+",negate=T))
}

# leave only the timepoint and the final results
if(tp=="FP"){
  rm(list=setdiff(ls(), c("res_check","tp","smpl","dte","pnls","cor","cr_perc")))
}

if(tp=="LKPK"){
  rm(list=setdiff(ls(), c("res_check","tp","smpl","dte","pnls","cor")))
}

