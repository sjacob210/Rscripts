library(shiny)
library(shinyFiles)
library(DT)
library(waiter)
setwd("/Users/samsonjacob/DummyTestFolder")
source("/Users/samsonjacob/Downloads/Dir_Choose_Inter/Read_CSV_DIR.R")

waiting_screen1 <- tagList(
    spin_timer(),
    h4("Working...")
)

ui<-fluidPage(sidebarLayout(
    sidebarPanel(
        h4(strong("Choose Sample Directory")),
        tags$style(".well { background-color:white; }"),
        shinyDirButton("dir", "1. Select", "Upload",style ="background-color:#E8580F;color:white" )
    ),
    
    mainPanel(
        h4("Files to Analyze"),
        DT::dataTableOutput("dir"), br(),
        actionButton("cont", "2. Generate_Coversheet",class ="btn-info"),
        use_waiter()
        #DT::dataTableOutput("tsx")
    )

))


server <- function(input,output,session){
    
    # dir
    shinyDirChoose(input, 'dir', roots = c("wd"=getwd()))
    print(getwd())
    pth_choose<-reactive(data.frame(FileNames=list.files(paste("/Users/samsonjacob/DummyTestFolder",unlist(input$dir)[2],sep="\\"),full.names = T,pattern="[\\d\\.].*[^COVERSHEET|^coversheet]*\\.csv")))
    csv_lis<-reactive(list.files(paste("/Users/samsonjacob/DummyTestFolder",unlist(input$dir)[2],sep="\\"),full.names = T,pattern="[\\d\\.].*[^COVERSHEET|^coversheet]*\\.csv"))
    outside<-reactive(as.character(unlist(input$dir)[2]))
    output$dir<-DT::renderDataTable(pth_choose(),options=list(dom="t"))
    observeEvent(input$cont,{
    test<-read_multi_csv(csv_lis())
    waiter_show(html=waiting_screen1,color="#2b2330")
    #write.csv(csv_lis(),"CSV_LIS.csv")
    source("./Downloads/Dir_Choose_Inter/generate_FlowCoverSheet.R",local=T)
    #output$tsx<-DT::renderDataTable(res_check)
    source("./Downloads/Dir_Choose_Inter/writ_docx3.R",local=T)
    hide_waiter()
    showModal(modalDialog(title="Status","Coversheet Generated!"))
    })
}

shinyApp(ui = ui, server = server)