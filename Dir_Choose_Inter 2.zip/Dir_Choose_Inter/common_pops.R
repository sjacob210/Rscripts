

panel1_vals<-c("% B cells | Blasts (of Live WBC single cells)","% Monocytes (of Live WBC single cells)", "% NK cells (of Live WBC single cells)")
panel1_thresh<-c(30,30,20)


# panel 3
pd1_vals<- c("CD279+ (of CAR- Thelper)","CD279+ (of CAR- Tcyto)",
             "CD279+ (of CAR+ Thelper)","CD279+ (of CAR+ Tcyto)")

lag_vals <- c("%CD279+ CD223+ (of CAR-Tcyto)","%CD279+ CD223+ (of CAR-Thelper)",
              "%CD279+ CD223+ (of CAR+Tcyto)","%CD279+ CD223+ (of CAR+Thelper)")

tim3_vals <-c("%CD279+ CD366+ (of CAR-Tcyto)","%CD279+ CD366+ (of CAR-Thelper)",
              "%CD279+ CD366+ (of CAR+Tcyto)","%CD279+ CD366+ (of CAR+Thelper)")

twob4_vals <-c("%CD279+ CD244+ (of CAR-Tcyto)","%CD279+ CD244+ (of CAR-Thelper)",
              "%CD279+ CD244+ (of CAR+Tcyto)","%CD279+ CD244+ (of CAR+Thelper)")
panel3_vals <- c(pd1_vals,lag_vals,tim3_vals,twob4_vals)
panel3_thresh <- c(50,50,
                   50,50,
                   30,30,
                   30,30,
                   30,30,
                   30,30,
                   30,30,
                   30,30)

 
# panel3_df<-data.frame(row.names=seq(1:length(panel3_thresh)))
# panel3_df["Population Name"]<-panel3_vals
# panel3_df["Thresh"]<-panel3_thresh
# panel3_df["Panel"]<-"Exhausted"

## panel 4
panel4_vals<- c("CD27- | CD28- (of CAR-, Tcyto)",
                    "CD27- | CD28- (of CAR-, Thelper)",
                    "CD27- | CD28- (of CAR+, Tcyto)",
                    "CD27- | CD28- (of CAR+, Thelper)",
                    "KLRG-1+ (of CAR-, Tcyto)",
                    "KLRG-1+ (of CAR-, Thelper)",
                    "KLRG-1+ (of CAR+, Tcyto)",
                    "KLRG-1+ (of CAR+, Thelper)")
panel4_thresh <- c(50,50,
                      50,50,
                      30,30,
                      30,30)


# panel4_df <- data.frame(row.names=seq(1:length(ImmunoSen_thresh)))
# panel4_df["Population Name"]<-ImmunoSen_Panel
# panel4_df["Thresh"]<-ImmunoSen_thresh
# panel4_df["Panel"]<-"Senescence "

Activation_Panel_lkpk<- c("HLA-DR+ |  CD38+ (of CAR- Tcyto)",
                     "HLA-DR+ |  CD25+ (of CAR- Tcyto)",
                     "%HLA-DR+ (of CAR-Tcyto)",
                     "%CD25+ (of CAR- Tcyto)",
                     "HLA-DR+ |  CD38+ (of CAR- Thelper)",
                     "HLA-DR+ |  CD25+ (of CAR- Thelper)",
                     "%HLA-DR+ (of CAR-Thelper)",
                     "%CD25+ (of CAR-Thelper)")

Activation_Panel_fp<- c("HLA-DR+ |  CD38+ (of CAR+ Tcyto)",
                          "HLA-DR+ |  CD25+ (of CAR+ Tcyto)",
                          "%HLA-DR+ (of CAR+Tcyto)",
                          "%CD25+ (of CAR+ Tcyto)",
                          "HLA-DR+ |  CD38+ (of CAR+ Thelper)",
                          "HLA-DR+ |  CD25+ (of CAR+ Thelper)",
                          "%HLA-DR+ (of CAR+Thelper)",
                          "%CD25+ (of CAR+Thelper)")

if(tp=="LKPK"){
  Activation_Panel<- Activation_Panel_lkpk
  Activation_thresh<-rep(20,length(Activation_Panel))
  Activation_Panel <-c(Activation_Panel,"%Tregs (of CAR- Thelper)")
  Activation_thresh<-c(Activation_thresh,10)
}else{
  Activation_Panel<-c(Activation_Panel_lkpk,Activation_Panel_fp)
  Activation_thresh<-rep(20,length(Activation_Panel))
}

# panel5_df <- data.frame(row.names=seq(1:length(Activation_Panel)))
# panel5_df["Population Name"]<-Activation_Panel
# panel5_df["Thresh"]<-Activation_thresh
# panel5_df["Panel"]<-"Activated-Treg"


#Early diff behaves differently
ED_Panel <-c("CD27+ | CD28+ (of CAR-, Tcyto)","CD27+ | CD28+ (of CAR-, Thelper)",
             "CD27+ | CD28+ (of CAR+, Tcyto)","CD27+ | CD28+ (of CAR+, Thelper)")

ed_thresh <- rep(20,length(ED_Panel))

# ed_df <- data.frame(row.names=seq(1:length(ED_Panel)))
# ed_df["Population Name"]<-ED_Panel
# ed_df["Thresh"]<-ed_thresh
# ed_df["Panel"]<-"Senescence "
######################################################################################################## get all the interested populations 
#correct Effector
getv<- function(x){
  require(stringr)
  # get > & percentage and car+ /-
  vals1<-str_extract(toString(x),pattern="^[><]\\s\\d+%") # >50%
  vals2<-str_extract(toString(x),pattern="(?=CAR+|-).*\\s+") # CAR+/-
  #k<- strsplit(vals1,"[[:space:]]+")
  y<-paste("of",strsplit(vals2,"[[:space:]]+"),sep=" ")
  out<-paste(vals1,y,sep=" ")
  #return(unlist(out))
  return(out)
}

# construct all the possiblities of Effector
great_vals<-c("> 50% Sum_Effector of CAR- Tcyto","> 50% Sum_Effector of CAR- Thelper","> 50% Sum_Effector of CAR+ Tcyto","> 50% Sum_Effector of CAR+ Thelper")
less_vals<-c("< 50% Sum_Effector of CAR- Tcyto","< 50% Sum_Effector of CAR- Thelper","< 50% Sum_Effector of CAR+ Tcyto","< 50% Sum_Effector of CAR+ Thelper")
tp_vals<-rep(c("LKPK","LKPK","FP","FP"),2)

# create a df for Effector values
eff_df<-data.frame(row.names=seq(1:8))
eff_df["RESULTS"]<-c(great_vals,less_vals)
eff_df["timepoint"]<-tp_vals
eff_df["OKVAL"]<-rep(c("Cytotoxic cells are terminal maturated (E+EM)","Helper cells are terminal maturated (E+EM)"),2)

# apply the getv function to RESULTS to correct names
eff_df["Corrected"]<-sapply(eff_df$RESULTS,function(x){getv(x)})
eff_df["final"]<-paste(eff_df$Corrected,eff_df$OKVAL)
eff_df<-eff_df[,c("RESULTS","final")]

############################################################################################### PANEL3 EXHAUSTION
exh_less<-c("< 30% %CD279+ CD223+ (of CAR-Tcyto)", "< 30% %CD279+ CD223+ (of CAR-Thelper)", "< 30% %CD279+ CD223+ (of CAR+Tcyto)", 
            "< 30% %CD279+ CD223+ (of CAR+Thelper)", "< 30% %CD279+ CD366+ (of CAR-Tcyto)", "< 30% %CD279+ CD366+ (of CAR-Thelper)", 
            "< 30% %CD279+ CD366+ (of CAR+Tcyto)", "< 30% %CD279+ CD366+ (of CAR+Thelper)", "< 50% CD279+ (of CAR- Tcyto)", 
            "< 50% CD279+ (of CAR- Thelper)", "< 50% CD279+ (of CAR+ Tcyto)", "< 50% CD279+ (of CAR+ Thelper)")

exh_grtr<-c("> 30% %CD279+ CD223+ (of CAR-Tcyto)", "> 30% %CD279+ CD223+ (of CAR-Thelper)", "> 30% %CD279+ CD223+ (of CAR+Tcyto)", 
            "> 30% %CD279+ CD223+ (of CAR+Thelper)", "> 30% %CD279+ CD366+ (of CAR-Tcyto)", "> 30% %CD279+ CD366+ (of CAR-Thelper)", 
            "> 30% %CD279+ CD366+ (of CAR+Tcyto)", "> 30% %CD279+ CD366+ (of CAR+Thelper)", "> 50% CD279+ (of CAR- Tcyto)", 
            "> 50% CD279+ (of CAR- Thelper)", "> 50% CD279+ (of CAR+ Tcyto)", "> 50% CD279+ (of CAR+ Thelper)", "> 50% CD279+ (of CAR+ Tcyto)",
            "> 50% CD279+ (of CAR+ Thelper)")

exh_less<- as.character(unique(exh_less))
exh_grtr<-as.character(unique(exh_grtr))

exh_df<-data.frame(row.names=seq(1:24))
exh_df["RESULTS"]<-c(exh_grtr,exh_less)


colx<-c("Population Name","Threshold",  "File Name",  "Experiment Id" ,"Time Point", "Template",   "Panel", "Value","Source","Sampling Point","Date","Version","Test","RESULTS")


##effector + effector memory
#eff_values<-c("% Effector (of CAR- Tcyto)","% Effector (of CAR- Thelper)","% Effector (of CAR+ Tcyto)","% Effector (of CAR+ Thelper)")
#eff_memvalues<-c("% Effector Memory (of CAR- Tcyto)","% Effector Memory (of CAR- Thelper)","% Effector Memory (of CAR+ Tcyto)","% Effector Memory (of CAR+ Thelper)")

##effector
# generate_effsums<-function(test){
#   mm<- test %>%
#     dplyr::filter(`Population Name`%in% c(eff_values,eff_memvalues))%>%
#     dplyr::mutate(cr=ifelse(str_detect(pattern = "CAR\\+",string = `Population Name`),"CarPos","CarNeg")) %>%
#     dplyr::mutate(cd=ifelse(str_detect(pattern="Tcyto",string=`Population Name`),"Tcyto","Thelper")) %>%
#     dplyr::group_by(`cr`,`cd`)%>%
#     dplyr::mutate(sm=sum(`Value`))%>%
#     dplyr::select(`sm`,`cr`,`cd`)%>%
#     dplyr::distinct(`sm`,.keep_all=T)%>%
#     dplyr::mutate(pop=paste("Sum_EffxEffMem",paste(`cr`,`cd`,sep="_"),sep="_"))
#   return(mm)
# }

analyze_tcellsub <- function(df){  
  require(dplyr)
  impvals<- c("% Effector","ratio")
  dfx <- df[df$`Panel` %in% c("T cell subsets"),] # subset only T cell subsets
  dfx <- dfx %>%
    dplyr::filter(str_detect(`Population Name`,paste(impvals,collapse="|"))) #find effector and ratio
  Split <- strsplit(as.character(dfx$`Population Name`), " (", fixed = TRUE)
  dfx$Eff <- sapply(Split, "[", 1)
  dfx$Cell <- sapply(Split,"[",2)
  eff_sum<-dfx %>%
    dplyr:: group_by(`Cell`)%>%
    tidyr:: drop_na() %>%
    dplyr:: summarise(Value = sum(`Value`))
  eff_sum$`Population Name` <- paste("Sum_Effector",gsub(")","",eff_sum$Cell))
  eff_sum$Cell <- NULL
  colx<- setdiff(colnames(dfx),c("Population Name","Value","Cell","Eff")) # remove population name
  for(c in 1:length(colx)){
    val_c <- as.character(colx)[c]
    eff_sum[val_c]<- as.character(unlist(unique(dfx[val_c])))[1]
  }
  res_df <- dplyr::bind_rows(dfx,eff_sum)
  res_df$Cell <- NULL
  res_df$Eff <- NULL
  return(res_df)
}

# functions
analyze_panel <- function(df,panelnm,thresh_vals,pop_vals,neg=F){
  require(tidyverse)
  dfx <-df[df$`Panel` %in% c(panelnm),] # subset the panel
  dfx<-dfx[match(pop_vals, dfx$`Population Name`),] # maintain order
  df_Thresh1 <- as.data.frame(tibble(Threshold=thresh_vals,Population=pop_vals))
  colnames(df_Thresh1)<-c("Threshold","Population Name")
  p1 <- subset(dfx,dfx$`Population Name`%in%pop_vals)
  found<- merge(df_Thresh1,p1,by="Population Name")
  if(neg==T){
    found$Test <- found$Value < found$Threshold
    found$Threshold2 <- gsub("\\s","",paste(found$Threshold,"%"))
    found$RESULTS<- ifelse(found$Test==T,paste("<",paste(as.character(found$Threshold2),found$`Population Name`)),
                           paste(">",paste(as.character(found$Threshold2),found$`Population Name`)))
  }else{
    found$Test <- found$Value > found$Threshold # False means it deviates
    found$Threshold2 <- gsub("\\s","",paste(found$Threshold,"%"))
    found$RESULTS<- ifelse(found$Test==T,paste(">",paste(as.character(found$Threshold2),found$`Population Name`)),
                           paste("<",paste(as.character(found$Threshold2),found$`Population Name`)))
  }
  found$Threshold2<-NULL
  return(found)
}