library(reshape2)
library(stringr)
library(stringi)
library(plyr)

#test_path<-"C:\\Users\\Public\\dist\\MPAAFA1\\FP"
#test_path<-"C:\\Users\\Public\\dist\\MPAAH81\\FP"
#test_path<-"C:\\Users\\Public\\Test Folder for Flow Cover Sheets\\MPAA092_FP"

######################################################################################### preloaded definitions
merged_DF_vals <-c("variable","SampleID","Time point","value","Sampling") # values before
cartman_vals <-c("Population Name","Experiment Id","Time Point","Value","Sampling Point") 


#remove bad characters, generecized
sub_bads <-function(df,char){
  cols <- colnames(df)
  v1<-gsub(char,"",cols)
  return(v1)
}

get_csv_name <-function(x){
  # ::Arg:: x= path to csv file (string)
  # ::Return:: string of just the .csv file (string)
  return(str_extract(toString(x),pattern = "([^\\//]+$)"))
}

# Transformation function (unaltered from legacy code turned into a function)
csv_read <- function(fil){
  # ::Arg(fil) = file path (str)
  # ::Arg(loc) = url path (str)
  # ::Out(short) = dataframe of exploded files (dataframe)
  cur<-Sys.time()
  flowdata <- read.csv(fil,header=T,sep=",",check.names=F) # read in csv
  colnames(flowdata)[1]<- "File Name" # correct filename
  short <- flowdata[flowdata[,1]!="Mean" & flowdata[,1]!="SD",2:ncol(flowdata)-1] # drop rows
  short <- melt(id.vars=c(1:5),short) # use the first 5 columns as indexes and explode
  short$Source <- get_csv_name(fil)
  short$Sampling <- "" # why is this blank?
  short$Date <-strftime(cur,format="%Y-%m-%d")
  short$Version<-"Version 3"
  return(short)
}
#correct header_function
correct_colnames <- function(mergedf){
  names_check <- sub_bads(mergedf,'#') #remove hashtags
  dict_new <-merged_DF_vals                  # apply dict
  dict_cartman <- cartman_vals
  cor<-mapvalues(names_check,dict_new,dict_cartman,warn_missing = F)
  colnames(mergedf)<-cor
  return(mergedf)
}

##completely numbers
get_sample_name3 <- function(x){
  name1<- str_extract(toString(x),pattern="(?=\\d+).*(?=LKPK|FP)") # everything after the period
  name1<- str_extract(trimws(toString(name1)),pattern="(?=[A-Z]+\\d).*") # everything after the period
  name1<- gsub("V3_",replacement = "",x=name1)
  return(name1)
}

getallpos <- function(x){
  v1 <- trimws(str_extract(toString(x),pattern="(.*)(?=FP|LKPK|).*$")) # anything before LKPK or FP
  return(get_sample_name3(v1))
}

# Multi_file handling
read_multi_csv <- function(lisnam){
  # ::Arg(lisnam) = list of files (list)
  # ::Out(df_list) = all chosen files as dataframes in a list (list)
  #lisnam= list.files(dirtocheck,full.names = T,pattern=".csv")
  df_list <- list() # instantiate empty list
  for(f in 1:length(lisnam)){ # for each filenames
    short <- csv_read(lisnam[f]) # run the read/transformation script
    val<-getallpos(trimws(as.character(unique(short$`File Name`))))
    short["#SampleID"]<-val
    short<-correct_colnames(short)
    #short$Date <- labkey.url.params$sample_Date # update column with url params
    df_list[[f]]<- short # place formatted df in list
  }
  return(dplyr::bind_rows(df_list))
}


#test<-read_multi_csv(list.files(test_path,full.names=T,pattern="[\\d\\.].*[^COVERSHEET|^coversheet]*\\.csv"))






